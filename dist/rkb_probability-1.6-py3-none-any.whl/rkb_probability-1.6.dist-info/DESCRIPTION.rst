# rkb_distributions package This package include Gaussian and Bionomial distribution packages. It’s come with mean, standard deviation and plot histogram.

## File file details - Gaussian()

## Installation Install using pip: 

```
pip install rkb-probability 
```

